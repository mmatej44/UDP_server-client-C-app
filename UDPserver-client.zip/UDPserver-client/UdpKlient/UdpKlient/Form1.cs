using System;
using System.Windows.Forms;

namespace UdpKlient
{
    public partial class Form1 : Form
    {
        private UdpTextClient client;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            client = new UdpTextClient(AppendZpravy, AppendLog);
            client.Start(6768);
            btnStart.Enabled = false;
        }

        private void AppendZpravy(string message)
        {
            if (tbZpravy.InvokeRequired)
            {
                tbZpravy.Invoke(new Action<string>(AppendZpravy), message);
                return;
            }
            tbZpravy.AppendText(message + Environment.NewLine);
        }

        private void AppendLog(string message)
        {
            if (tbLog.InvokeRequired)
            {
                tbLog.Invoke(new Action<string>(AppendLog), message);
                return;
            }
            tbLog.AppendText(message + Environment.NewLine);
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (client != null)
                client.Stop();
        }
    }
}