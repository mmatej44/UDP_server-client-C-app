﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

public class UdpTextClient
{
    private UdpClient udp;
    private Action<string> onMessage;
    private Action<string> log;

    public UdpTextClient(Action<string> messageCallback, Action<string> logCallback)
    {
        onMessage = messageCallback;
        log = logCallback;
    }

    public void Start(int port)
    {
        udp = new UdpClient(port);
        log("Klient posloucha na portu: " + port.ToString());

        Thread t = new Thread(ReceiveLoop);
        t.IsBackground = true;
        t.Start();
    }

    private void ReceiveLoop()
    {
        while (true)
        {
            try
            {
                IPEndPoint ep = new IPEndPoint(IPAddress.Any, 0);
                byte[] data = udp.Receive(ref ep);
                string message = Encoding.UTF8.GetString(data);
                log("Prijato z: " + ep.Address.ToString() + " zprava: " + message);
                onMessage(message);
            }
            catch
            {
                break;
            }
        }
    }

    public void Stop()
    {
        if (udp != null)
            udp.Close();
    }
}