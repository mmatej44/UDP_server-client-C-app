﻿namespace UdpKlient
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.labelZpravy = new System.Windows.Forms.Label();
            this.tbZpravy = new System.Windows.Forms.RichTextBox();
            this.labelLog = new System.Windows.Forms.Label();
            this.tbLog = new System.Windows.Forms.RichTextBox();
            this.btnStart = new System.Windows.Forms.Button();
            this.SuspendLayout();

            this.labelZpravy.AutoSize = true;
            this.labelZpravy.Location = new System.Drawing.Point(190, 10);
            this.labelZpravy.Text = "Zpravy";

            this.tbZpravy.Location = new System.Drawing.Point(12, 30);
            this.tbZpravy.Size = new System.Drawing.Size(460, 130);
            this.tbZpravy.ReadOnly = true;

            this.labelLog.AutoSize = true;
            this.labelLog.Location = new System.Drawing.Point(210, 175);
            this.labelLog.Text = "Log";

            this.tbLog.Location = new System.Drawing.Point(12, 195);
            this.tbLog.Size = new System.Drawing.Size(460, 130);
            this.tbLog.ReadOnly = true;

            this.btnStart.Location = new System.Drawing.Point(190, 340);
            this.btnStart.Size = new System.Drawing.Size(100, 28);
            this.btnStart.Text = "Start";
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);

            this.ClientSize = new System.Drawing.Size(484, 385);
            this.Controls.Add(this.labelZpravy);
            this.Controls.Add(this.tbZpravy);
            this.Controls.Add(this.labelLog);
            this.Controls.Add(this.tbLog);
            this.Controls.Add(this.btnStart);
            this.Text = "UDP message client";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Label labelZpravy;
        private System.Windows.Forms.RichTextBox tbZpravy;
        private System.Windows.Forms.Label labelLog;
        private System.Windows.Forms.RichTextBox tbLog;
        private System.Windows.Forms.Button btnStart;
    }
}