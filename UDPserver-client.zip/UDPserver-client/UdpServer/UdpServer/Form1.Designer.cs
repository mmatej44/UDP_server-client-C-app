﻿namespace UdpServer
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            labelIP = new Label();
            tbClientIP = new TextBox();
            btnStart = new Button();
            labelZprava = new Label();
            tbMessage = new TextBox();
            btnSend = new Button();
            tbLog = new RichTextBox();
            SuspendLayout();
            // 
            // labelIP
            // 
            labelIP.AutoSize = true;
            labelIP.Location = new Point(12, 15);
            labelIP.Name = "labelIP";
            labelIP.Size = new Size(54, 15);
            labelIP.TabIndex = 0;
            labelIP.Text = "IP adresa";
            // 
            // tbClientIP
            // 
            tbClientIP.Location = new Point(80, 12);
            tbClientIP.Name = "tbClientIP";
            tbClientIP.Size = new Size(200, 23);
            tbClientIP.TabIndex = 1;
            tbClientIP.Text = "127.0.0.1";
            tbClientIP.TextChanged += tbClientIP_TextChanged;
            // 
            // btnStart
            // 
            btnStart.Location = new Point(290, 10);
            btnStart.Name = "btnStart";
            btnStart.Size = new Size(75, 24);
            btnStart.TabIndex = 2;
            btnStart.Text = "Start";
            btnStart.Click += btnStart_Click;
            // 
            // labelZprava
            // 
            labelZprava.AutoSize = true;
            labelZprava.Location = new Point(150, 48);
            labelZprava.Name = "labelZprava";
            labelZprava.Size = new Size(43, 15);
            labelZprava.TabIndex = 3;
            labelZprava.Text = "Zprava";
            // 
            // tbMessage
            // 
            tbMessage.Location = new Point(12, 65);
            tbMessage.Name = "tbMessage";
            tbMessage.Size = new Size(280, 23);
            tbMessage.TabIndex = 4;
            // 
            // btnSend
            // 
            btnSend.Location = new Point(300, 63);
            btnSend.Name = "btnSend";
            btnSend.Size = new Size(75, 24);
            btnSend.TabIndex = 5;
            btnSend.Text = "Odeslat";
            btnSend.Click += btnSend_Click;
            // 
            // tbLog
            // 
            tbLog.Location = new Point(12, 100);
            tbLog.Name = "tbLog";
            tbLog.ReadOnly = true;
            tbLog.Size = new Size(460, 220);
            tbLog.TabIndex = 6;
            tbLog.Text = "";
            // 
            // Form1
            // 
            ClientSize = new Size(484, 335);
            Controls.Add(labelIP);
            Controls.Add(tbClientIP);
            Controls.Add(btnStart);
            Controls.Add(labelZprava);
            Controls.Add(tbMessage);
            Controls.Add(btnSend);
            Controls.Add(tbLog);
            Name = "Form1";
            Text = "UDP message server";
            FormClosing += Form1_FormClosing;
            ResumeLayout(false);
            PerformLayout();
        }

        private System.Windows.Forms.Label labelIP;
        private System.Windows.Forms.TextBox tbClientIP;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Label labelZprava;
        private System.Windows.Forms.TextBox tbMessage;
        private System.Windows.Forms.Button btnSend;
        private System.Windows.Forms.RichTextBox tbLog;
    }
}