﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

public class UdpTextServer
{
    private UdpClient udpClient;
    private Thread receiveThread;
    private Action<string> logCallback;
    private bool running = false;

    public UdpTextServer(Action<string> logCallback)
    {
        this.logCallback = logCallback;
    }

    public void Configure(int port)
    {
        udpClient = new UdpClient(new IPEndPoint(IPAddress.Any, port));
        running = true;
        receiveThread = new Thread(ReceiveLoop);
        receiveThread.IsBackground = true;
        receiveThread.Start();
    }

    private void ReceiveLoop()
    {
        while (running)
        {
            try
            {
                IPEndPoint remoteEP = new IPEndPoint(IPAddress.Any, 0);
                byte[] data = udpClient.Receive(ref remoteEP);
                string message = Encoding.UTF8.GetString(data);
                logCallback("Prijato z: " + remoteEP.Address.ToString() + " zprava: " + message);
            }
            catch
            {
                break;
            }
        }
    }

    public void SendMessage(string message, string clientIP, int clientPort)
    {
        IPEndPoint target = new IPEndPoint(IPAddress.Parse(clientIP), clientPort);
        byte[] data = Encoding.UTF8.GetBytes(message);
        udpClient.Send(data, data.Length, target);
    }

    public void Stop()
    {
        running = false;
        if (udpClient != null)
            udpClient.Close();
    }
}