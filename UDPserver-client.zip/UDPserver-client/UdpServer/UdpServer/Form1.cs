using System;
using System.Windows.Forms;

namespace UdpServer
{
    public partial class Form1 : Form
    {
        private UdpTextServer server;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            server = new UdpTextServer(AppendLog);
            server.Configure(6767);
            AppendLog("Server spusten.");
            AppendLog("Server ready ... Client at " + tbClientIP.Text + ":6768");
            btnStart.Enabled = false;
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            if (server == null)
            {
                AppendLog("Nejdrive spustte server.");
                return;
            }
            server.SendMessage(tbMessage.Text, tbClientIP.Text, 6768);
            AppendLog("Odeslano " + tbMessage.Text);
            tbMessage.Clear();
        }

        private void AppendLog(string message)
        {
            if (tbLog.InvokeRequired)
            {
                tbLog.Invoke(new Action<string>(AppendLog), message);
                return;
            }
            tbLog.AppendText(message + Environment.NewLine);
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (server != null)
                server.Stop();
        }

        private void tbClientIP_TextChanged(object sender, EventArgs e)
        {

        }
    }
}